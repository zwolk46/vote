const COLORS = ['#2563eb', '#16a34a', '#9333ea', '#ea580c', '#dc2626', '#0891b2', '#475569'];

const $ = (id) => document.getElementById(id);
let state = null;
let editingId = null;
let pending = null; // { type: 'switch', id } or { type: 'add' } waiting on the unsaved sign-in
let newColor = null;

async function call(type, payload = {}) {
  const res = await chrome.runtime.sendMessage({ type, ...payload });
  if (!res?.ok) throw new Error(res?.error || 'Something went wrong.');
  return res.result;
}

function showError(message) {
  $('error').textContent = message;
  $('error').hidden = !message;
}

async function busy(fn) {
  document.body.classList.add('busy');
  document.querySelectorAll('button, input').forEach((el) => (el.disabled = true));
  showError('');
  try {
    return await fn();
  } catch (e) {
    showError(e.message);
  } finally {
    document.body.classList.remove('busy');
    document.querySelectorAll('button, input').forEach((el) => (el.disabled = false));
  }
}

async function refresh() {
  state = await call('status');
  render();
}

function el(tag, props = {}, ...children) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children);
  return node;
}

function swatches(container, selected, onPick) {
  container.replaceChildren(
    ...COLORS.map((color) =>
      el('button', {
        type: 'button',
        className: 'swatch',
        title: color,
        style: `background:${color}`,
        role: 'radio',
        ariaChecked: String(color === selected),
        onclick: () => {
          onPick(color);
          container.querySelectorAll('.swatch').forEach((s) => s.setAttribute('aria-checked', String(s.title === color)));
        },
      }),
    ),
  );
}

function render() {
  const { accounts, current, activeId, settings } = state;
  const unsaved = current.signedIn && !current.accountId;
  const lastActive = accounts.find((a) => a.id === activeId);

  // Unsaved sign-in card
  $('unsaved').hidden = !unsaved;
  if (unsaved) {
    const input = $('new-label');
    input.placeholder = accounts.length === 0 ? 'Name, e.g. Work' : 'Name, e.g. Personal';
    if (!newColor) newColor = COLORS.find((c) => !accounts.some((a) => a.color === c)) ?? COLORS[0];
    swatches($('new-swatches'), newColor, (c) => (newColor = c));
    const update = $('update-existing');
    update.hidden = !lastActive;
    if (lastActive) {
      update.textContent = `Update “${lastActive.label}”`;
      $('unsaved-hint').textContent = `If you just signed in to “${lastActive.label}” again, update it. Otherwise save this as a new account.`;
    } else {
      $('unsaved-hint').textContent = 'Name it so you can switch back to it later.';
    }
    $('decision').hidden = !pending;
  }

  // Account list
  $('accounts').replaceChildren(
    ...accounts.map((account, i) => (account.id === editingId ? editRow(account) : accountRow(account, i, current))),
  );

  // Empty and signed-out hints
  let hint = '';
  if (accounts.length === 0 && !current.signedIn) hint = 'Sign in to claude.ai in this browser, then open this menu to save that account.';
  else if (accounts.length > 0 && !current.signedIn) hint = 'Signed out of claude.ai. Pick a saved account above, or sign in to add one.';
  $('empty').textContent = hint;
  $('empty').hidden = !hint;
  $('add').textContent = accounts.length === 0 && !current.signedIn ? 'Open claude.ai sign-in' : '+ Sign in to another account';

  $('opt-clear').checked = settings.clearSiteData;
  $('opt-indicator').checked = settings.showIndicator;
}

function accountRow(account, index, current) {
  const active = account.id === current.accountId;
  return el(
    'li',
    { className: `account${active ? ' active' : ''}` },
    el(
      'button',
      {
        type: 'button',
        className: 'switch',
        title: active ? `${account.label} is active` : `Switch to ${account.label}` + (index < 9 ? ` (${index + 1})` : ''),
        onclick: () => !active && doSwitch(account.id),
      },
      el('span', { className: 'dot', style: `background:${account.color}` }),
      el('span', { className: 'name', textContent: account.label }),
      el('span', { className: 'state', textContent: active ? 'Active' : 'Switch' }),
    ),
    el('button', {
      type: 'button',
      className: 'icon',
      title: `Edit ${account.label}`,
      ariaLabel: `Edit ${account.label}`,
      textContent: '✎',
      onclick: () => {
        editingId = account.id;
        render();
        document.querySelector('.edit-form input')?.focus();
      },
    }),
  );
}

function editRow(account) {
  let color = account.color;
  const input = el('input', { value: account.label, maxLength: 40, ariaLabel: 'Account name' });
  const picker = el('div', { className: 'swatches' });
  swatches(picker, color, (c) => (color = c));
  const form = el(
    'form',
    {
      className: 'edit-form',
      onsubmit: (e) => {
        e.preventDefault();
        busy(async () => {
          await call('updateAccount', { id: account.id, label: input.value, color });
          editingId = null;
          await refresh();
        });
      },
    },
    input,
    picker,
    el(
      'div',
      { className: 'buttons' },
      el(
        'span',
        { className: 'buttons' },
        el('button', { type: 'submit', className: 'primary', textContent: 'Save' }),
        el('button', {
          type: 'button',
          className: 'secondary',
          textContent: 'Cancel',
          onclick: () => {
            editingId = null;
            render();
          },
        }),
      ),
      el('button', {
        type: 'button',
        className: 'link danger',
        textContent: 'Remove',
        title: 'Forget this saved sign-in (does not log it out on claude.ai)',
        onclick: () => {
          if (!confirm(`Remove “${account.label}” from the switcher? Its saved sign-in is deleted from this browser.`)) return;
          busy(async () => {
            await call('removeAccount', { id: account.id });
            editingId = null;
            await refresh();
          });
        },
      }),
    ),
  );
  return el('li', { className: 'account editing' }, form);
}

async function runPending(discardCurrent = false) {
  const action = pending;
  if (!action) return;
  const result =
    action.type === 'switch'
      ? await call('switchTo', { id: action.id, discardCurrent })
      : await call('addAccount', { discardCurrent });
  if (result?.needsDecision) {
    await refresh(); // shows the "save it first" choice
    return;
  }
  pending = null;
  window.close();
}

function doSwitch(id) {
  pending = { type: 'switch', id };
  busy(() => runPending());
}

$('add').addEventListener('click', () => {
  pending = { type: 'add' };
  busy(() => runPending());
});

$('discard').addEventListener('click', () => busy(() => runPending(true)));

$('save-form').addEventListener('submit', (e) => {
  e.preventDefault();
  busy(async () => {
    await call('saveCurrent', { label: $('new-label').value, color: newColor });
    $('new-label').value = '';
    newColor = null;
    if (pending) return runPending();
    await refresh();
  });
});

$('update-existing').addEventListener('click', () =>
  busy(async () => {
    await call('saveCurrent', { updateId: state.activeId });
    if (pending) return runPending();
    await refresh();
  }),
);

$('opt-clear').addEventListener('change', (e) =>
  busy(() => call('setSettings', { settings: { clearSiteData: e.target.checked } })),
);
$('opt-indicator').addEventListener('change', (e) =>
  busy(() => call('setSettings', { settings: { showIndicator: e.target.checked } })),
);

// Number keys switch accounts while the menu is open (1 = first account, ...).
document.addEventListener('keydown', (e) => {
  if (e.target.closest?.('input, textarea') || e.altKey || e.ctrlKey || e.metaKey) return;
  const n = Number(e.key);
  const account = Number.isInteger(n) && n >= 1 ? state?.accounts[n - 1] : null;
  if (account && account.id !== state.current.accountId) doSwitch(account.id);
});

chrome.commands.getAll().then((commands) => {
  const shortcut = commands.find((c) => c.name === 'cycle-account')?.shortcut;
  if (shortcut) $('shortcut').textContent = shortcut;
});

refresh().catch((e) => showError(e.message));
