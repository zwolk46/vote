const text = decodeURIComponent(location.hash.slice(1));
if (text) {
  document.getElementById('msg').textContent = text;
  document.title = text;
}
