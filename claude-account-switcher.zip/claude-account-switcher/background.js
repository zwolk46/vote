// Claude Account Switcher: background service worker.
//
// claude.ai keeps you signed in with cookies (chiefly `sessionKey`). This worker keeps one
// snapshot of the claude.ai cookies per saved account and swaps snapshots on demand. Nothing
// is sent anywhere: snapshots live in this browser profile's extension storage.

const SITE = 'https://claude.ai';
const COOKIE_DOMAIN = 'claude.ai'; // getAll() also matches .claude.ai and subdomains
const SESSION_COOKIE = 'sessionKey';
const ORG_COOKIE = 'lastActiveOrg';
// Cloudflare bot-protection cookies belong to the device, not the account. Leaving them in
// place means switching does not trigger a fresh "are you human" check.
const UNMANAGED = [/^__cf/, /^cf_/, /^_cfuvid$/];
const DEFAULT_SETTINGS = { clearSiteData: true, showIndicator: true };

// Keep the cookie snapshots away from content scripts (extension pages and this worker only).
try {
  chrome.storage.local.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' });
} catch (_) {}

// ---------- storage ----------

async function load() {
  const s = await chrome.storage.local.get(['accounts', 'activeId', 'settings']);
  return {
    accounts: s.accounts ?? [],
    activeId: s.activeId ?? null,
    settings: { ...DEFAULT_SETTINGS, ...(s.settings ?? {}) },
  };
}

const persist = (patch) => chrome.storage.local.set(patch);

// One mutating operation at a time, so a double click can't interleave two switches.
let queue = Promise.resolve();
function exclusive(fn) {
  return (...args) => {
    const run = queue.then(() => fn(...args));
    queue = run.catch(() => {});
    return run;
  };
}

// ---------- cookies ----------

const isManaged = (c) => !UNMANAGED.some((re) => re.test(c.name));
const cookieUrl = (c) => `https://${c.domain.replace(/^\./, '')}${c.path || '/'}`;

async function readCookies() {
  return (await chrome.cookies.getAll({ domain: COOKIE_DOMAIN })).filter(isManaged);
}

function strip(c) {
  const { name, value, domain, hostOnly, path, secure, httpOnly, sameSite, session, expirationDate } = c;
  return { name, value, domain, hostOnly, path, secure, httpOnly, sameSite, session, expirationDate };
}

async function clearCookies() {
  const cookies = await readCookies();
  await Promise.all(
    cookies.map((c) => chrome.cookies.remove({ url: cookieUrl(c), name: c.name, storeId: c.storeId })),
  );
}

async function writeCookies(cookies) {
  const now = Date.now() / 1000;
  for (const c of cookies) {
    if (!c.session && c.expirationDate && c.expirationDate <= now) continue; // expired, skip
    const details = {
      url: cookieUrl(c),
      name: c.name,
      value: c.value,
      path: c.path,
      secure: c.secure,
      httpOnly: c.httpOnly,
      sameSite: c.sameSite,
    };
    if (!c.hostOnly) details.domain = c.domain; // host-only cookies (e.g. __Host-*) must not get a domain
    if (!c.session && c.expirationDate) details.expirationDate = c.expirationDate;
    try {
      await chrome.cookies.set(details);
    } catch (e) {
      console.warn('Could not restore cookie', c.name, e);
    }
  }
}

function identify(cookies) {
  const get = (name) => cookies.find((c) => c.name === name)?.value ?? null;
  return { sessionKey: get(SESSION_COOKIE), org: get(ORG_COOKIE) };
}

// Which saved account does the live session belong to? Exact session match first; otherwise
// the organization cookie (covers claude.ai refreshing the session key, or signing in again).
function findMatch(accounts, id) {
  if (!id.sessionKey) return null;
  const byKey = accounts.find((a) => a.sessionKey === id.sessionKey);
  if (byKey) return byKey;
  if (id.org) {
    const byOrg = accounts.filter((a) => a.orgs?.includes(id.org));
    if (byOrg.length === 1) return byOrg[0];
  }
  return null;
}

function applySnapshot(account, cookies, id, { resetOrgs = false } = {}) {
  account.cookies = cookies.map(strip);
  account.sessionKey = id.sessionKey;
  const orgs = resetOrgs ? [] : account.orgs ?? [];
  account.orgs = [...new Set([...orgs, id.org].filter(Boolean))];
  account.savedAt = Date.now();
}

// Copy the live session back into the account it belongs to, so a refreshed session isn't lost.
// Returns 'saved', 'signed-out' or 'unknown' (signed in to an account that isn't saved).
async function captureLive(st) {
  const cookies = await readCookies();
  const id = identify(cookies);
  if (!id.sessionKey) return { result: 'signed-out' };
  const account = findMatch(st.accounts, id);
  if (!account) return { result: 'unknown' };
  applySnapshot(account, cookies, id);
  return { result: 'saved', account };
}

// ---------- site data and tabs ----------

// Wipe what claude.ai keeps in page storage (cached conversations, drafts, settings) so nothing
// from one account shows up under the other. Cookies are handled separately above.
async function clearSiteData() {
  await chrome.browsingData.remove(
    { origins: [SITE] },
    { cacheStorage: true, indexedDB: true, localStorage: true, serviceWorkers: true, fileSystems: true },
  );
}

const claudeTabs = () => chrome.tabs.query({ url: ['https://claude.ai/*', 'https://*.claude.ai/*'] });

function waitForLoad(tabId, timeoutMs = 4000) {
  return new Promise((resolve) => {
    let sawLoading = false;
    const finish = () => {
      chrome.tabs.onUpdated.removeListener(onUpdated);
      chrome.tabs.onRemoved.removeListener(onRemoved);
      clearTimeout(timer);
      resolve();
    };
    const onUpdated = (id, info) => {
      if (id !== tabId) return;
      if (info.status === 'loading') sawLoading = true;
      if (info.status === 'complete' && sawLoading) finish();
    };
    const onRemoved = (id) => id === tabId && finish();
    const timer = setTimeout(finish, timeoutMs);
    chrome.tabs.onUpdated.addListener(onUpdated);
    chrome.tabs.onRemoved.addListener(onRemoved);
  });
}

// Move every claude.ai tab to a holding page before touching storage, so the old account's
// pages are fully unloaded and can't write anything back or send a message as the new account.
async function parkTabs(message) {
  const tabs = await claudeTabs();
  const url = chrome.runtime.getURL('switching.html') + '#' + encodeURIComponent(message);
  await Promise.all(
    tabs.map(async (t) => {
      const loaded = waitForLoad(t.id);
      try {
        await chrome.tabs.update(t.id, { url });
        await loaded;
      } catch (_) {}
    }),
  );
  return tabs.map((t) => t.id);
}

async function unparkTabs(tabIds, url) {
  if (tabIds.length === 0) {
    await chrome.tabs.create({ url });
    return;
  }
  await Promise.all(tabIds.map((id) => chrome.tabs.update(id, { url }).catch(() => {})));
}

// ---------- operations ----------

async function getStatus() {
  const st = await load();
  const id = identify(await readCookies());
  const match = findMatch(st.accounts, id);
  return {
    accounts: st.accounts.map(({ id, label, color, savedAt }) => ({ id, label, color, savedAt })),
    activeId: st.activeId,
    current: { signedIn: !!id.sessionKey, accountId: match?.id ?? null },
    settings: st.settings,
  };
}

async function switchTo({ id, discardCurrent = false }) {
  const st = await load();
  const target = st.accounts.find((a) => a.id === id);
  if (!target) throw new Error('That account is no longer saved.');

  const live = await captureLive(st);
  if (live.result === 'unknown' && !discardCurrent) return { needsDecision: true };
  if (live.account?.id === target.id) {
    await persist({ accounts: st.accounts, activeId: target.id });
    await refreshIndicators();
    return { alreadyActive: true };
  }

  const tabs = await parkTabs(`Switching to ${target.label}…`);
  await clearCookies();
  if (st.settings.clearSiteData) await clearSiteData();
  await writeCookies(target.cookies);
  await persist({ accounts: st.accounts, activeId: target.id });
  await unparkTabs(tabs, `${SITE}/new`);
  await refreshIndicators();
  return { switched: true };
}

async function addAccount({ discardCurrent = false } = {}) {
  const st = await load();
  const live = await captureLive(st);
  if (live.result === 'unknown' && !discardCurrent) return { needsDecision: true };

  const tabs = await parkTabs('Signing out so you can add another account…');
  await clearCookies();
  if (st.settings.clearSiteData) await clearSiteData();
  await persist({ accounts: st.accounts, activeId: null });
  await unparkTabs(tabs, `${SITE}/login`);
  await refreshIndicators();
  return { started: true };
}

async function saveCurrent({ label, color, updateId = null }) {
  const st = await load();
  const cookies = await readCookies();
  const id = identify(cookies);
  if (!id.sessionKey) throw new Error('You are not signed in to claude.ai in this browser profile.');

  let account;
  if (updateId) {
    account = st.accounts.find((a) => a.id === updateId);
    if (!account) throw new Error('That account is no longer saved.');
    applySnapshot(account, cookies, id, { resetOrgs: true });
  } else {
    const name = String(label ?? '').trim().slice(0, 40);
    if (!name) throw new Error('Give the account a name, e.g. Work or Personal.');
    account = { id: crypto.randomUUID(), label: name, color: color || '#2563eb', orgs: [] };
    applySnapshot(account, cookies, id);
    st.accounts.push(account);
  }
  // A live session belongs to exactly one saved account.
  for (const other of st.accounts) {
    if (other === account) continue;
    if (other.sessionKey === id.sessionKey) other.sessionKey = null;
    other.orgs = (other.orgs ?? []).filter((o) => o !== id.org);
  }
  await persist({ accounts: st.accounts, activeId: account.id });
  await refreshIndicators();
  return { id: account.id };
}

async function updateAccount({ id, label, color }) {
  const st = await load();
  const account = st.accounts.find((a) => a.id === id);
  if (!account) throw new Error('That account is no longer saved.');
  const name = String(label ?? account.label).trim().slice(0, 40);
  if (name) account.label = name;
  if (color) account.color = color;
  await persist({ accounts: st.accounts });
  await refreshIndicators();
}

// Forget a saved account. Doesn't touch the live session; use claude.ai's own "Log out"
// afterwards if you also want to end that session on Anthropic's side.
async function removeAccount({ id }) {
  const st = await load();
  const accounts = st.accounts.filter((a) => a.id !== id);
  await persist({ accounts, activeId: st.activeId === id ? null : st.activeId });
  await refreshIndicators();
}

async function setSettings({ settings }) {
  const st = await load();
  await persist({ settings: { ...st.settings, ...settings } });
  await refreshIndicators();
}

async function cycle() {
  const st = await load();
  if (st.accounts.length < 2) return { skipped: 'need-two-accounts' };
  const current = findMatch(st.accounts, identify(await readCookies()));
  const from = current ?? st.accounts.find((a) => a.id === st.activeId);
  const index = from ? st.accounts.indexOf(from) : -1;
  const next = st.accounts[(index + 1) % st.accounts.length];
  return switchTo({ id: next.id });
}

// ---------- toolbar badge and on-page label ----------

async function indicatorInfo() {
  const st = await load();
  const id = identify(await readCookies());
  const account = findMatch(st.accounts, id);
  if (account) return { show: st.settings.showIndicator, label: account.label, color: account.color };
  if (id.sessionKey) return { show: st.settings.showIndicator, label: 'Unsaved account', color: '#64748b' };
  return { show: false };
}

async function refreshIndicators() {
  const st = await load();
  const id = identify(await readCookies());
  const account = findMatch(st.accounts, id);

  if (account && st.activeId !== account.id) await persist({ activeId: account.id });

  let text = '';
  let color = '#64748b';
  let title = 'Claude accounts: signed out';
  if (account) {
    text = [...account.label][0]?.toUpperCase() ?? '';
    color = account.color;
    title = `Claude accounts: using ${account.label}`;
  } else if (id.sessionKey) {
    text = '?';
    title = 'Claude accounts: this sign-in is not saved yet (click to save it)';
  }
  await chrome.action.setBadgeText({ text });
  await chrome.action.setBadgeBackgroundColor({ color });
  try {
    await chrome.action.setBadgeTextColor({ color: '#ffffff' });
  } catch (_) {}
  await chrome.action.setTitle({ title });

  const info = await indicatorInfo();
  for (const tab of await claudeTabs()) {
    chrome.tabs.sendMessage(tab.id, { type: 'indicator-update', info }).catch(() => {});
  }
}

let refreshTimer = null;
function scheduleRefresh() {
  clearTimeout(refreshTimer);
  refreshTimer = setTimeout(() => refreshIndicators().catch(console.warn), 400);
}

// ---------- wiring ----------

const exclusiveOps = {
  switchTo: exclusive(switchTo),
  addAccount: exclusive(addAccount),
  saveCurrent: exclusive(saveCurrent),
  updateAccount: exclusive(updateAccount),
  removeAccount: exclusive(removeAccount),
  setSettings: exclusive(setSettings),
  cycle: exclusive(cycle),
};
const handlers = { status: getStatus, indicator: indicatorInfo, ...exclusiveOps };

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const handler = handlers[msg?.type];
  if (!handler) return false;
  // claude.ai pages (via the content script) may only ask what label to show.
  const fromExtensionPage = sender.id === chrome.runtime.id && sender.url?.startsWith(chrome.runtime.getURL(''));
  if (!fromExtensionPage && msg.type !== 'indicator') return false;
  Promise.resolve()
    .then(() => handler(msg))
    .then(
      (result) => sendResponse({ ok: true, result }),
      (error) => sendResponse({ ok: false, error: error?.message ?? String(error) }),
    );
  return true;
});

chrome.commands.onCommand.addListener(async (command) => {
  if (command !== 'cycle-account') return;
  const result = await exclusiveOps.cycle().catch((e) => ({ error: e.message }));
  if (result?.needsDecision || result?.skipped || result?.error) {
    // Can't switch silently (e.g. the live sign-in isn't saved yet); show the menu instead.
    try {
      await chrome.action.openPopup?.();
    } catch (_) {}
  }
});

chrome.cookies.onChanged.addListener(({ cookie }) => {
  const domain = cookie.domain.replace(/^\./, '');
  if (domain !== COOKIE_DOMAIN && !domain.endsWith(`.${COOKIE_DOMAIN}`)) return;
  if (cookie.name === SESSION_COOKIE || cookie.name === ORG_COOKIE) scheduleRefresh();
});

chrome.runtime.onInstalled.addListener(scheduleRefresh);
chrome.runtime.onStartup.addListener(scheduleRefresh);
