// Shows which saved account this claude.ai tab is using: a thin colored strip along the top
// edge with a small name tab. It ignores the mouse, so it never blocks the page.
(() => {
  let host = null;

  function render(info) {
    if (!info?.show) {
      host?.remove();
      host = null;
      return;
    }
    if (!host) {
      host = document.createElement('div');
      host.attachShadow({ mode: 'open' });
      document.documentElement.appendChild(host);
    }
    const root = host.shadowRoot;
    root.innerHTML = `
      <style>
        :host { all: initial; }
        .strip { position: fixed; inset: 0 0 auto 0; height: 3px; z-index: 2147483647; pointer-events: none; }
        .tab {
          position: fixed; top: 0; left: 50%; transform: translateX(-50%); z-index: 2147483647;
          pointer-events: none; padding: 1px 10px 3px; border-radius: 0 0 7px 7px;
          font: 600 11px/14px system-ui, -apple-system, "Segoe UI", sans-serif; letter-spacing: .02em;
          color: #fff; white-space: nowrap; max-width: 40vw; overflow: hidden; text-overflow: ellipsis;
        }
      </style>
      <div class="strip"></div><div class="tab" id="cas-account-label"></div>`;
    root.querySelector('.strip').style.background = info.color;
    const tab = root.querySelector('.tab');
    tab.style.background = info.color;
    tab.textContent = info.label;
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === 'indicator-update') render(msg.info);
  });

  chrome.runtime
    .sendMessage({ type: 'indicator' })
    .then((res) => res?.ok && render(res.result))
    .catch(() => {});
})();
