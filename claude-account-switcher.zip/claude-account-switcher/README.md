# Claude Account Switcher (Microsoft Edge)

A small, unofficial Edge extension that saves your claude.ai sign-ins (for example **Work** and
**Personal**) and switches between them in one click, in a single Edge profile. It is not made by
or affiliated with Anthropic.

## Before you install

If this is a firm-managed computer, check with IT first:

- **Extensions:** Managed Edge often blocks extensions loaded in developer mode.
- **Network:** Claude Enterprise admins can block every Claude account except the firm's on the
  firm network or device (Anthropic calls this "tenant restrictions"). If yours does, the personal
  account shows "Access restricted by network policy". This extension can't get around that, and
  isn't meant to.
- **Policy:** Firm policy may not allow a personal AI account on a work device at all.

## Install (about 2 minutes)

1. Unzip `claude-account-switcher.zip` somewhere permanent, such as `Documents\claude-account-switcher`.
   Edge loads the extension from that folder, so don't delete it.
2. In Edge, open `edge://extensions`.
3. Turn on **Developer mode** (the switch at the bottom left).
4. Click **Load unpacked** and select the `claude-account-switcher` folder (the one that contains `manifest.json`).
5. To keep the button visible, click the puzzle-piece icon in the toolbar, then the eye icon next to **Claude Account Switcher**.

Edge sometimes shows a "turn off developer mode extensions" prompt at startup. Choose to keep the extension.

## Set up both accounts (one time)

1. Sign in to claude.ai with your **work** account as usual. Click the extension button, type `Work`, and click **Save account**.
2. Click **+ Sign in to another account**. Your work account is signed out *in this browser only*:
   its session stays valid and saved. Then the claude.ai sign-in page opens.
3. Sign in with your **personal** account. Click the button, type `Personal`, and click **Save account**.

## Everyday use

- **Switch:** Click the button, then click the account. You can also press **Alt+Shift+C** to go to
  the next account, or press **1** or **2** while the menu is open. Change the shortcut at `edge://extensions/shortcuts`.
- **Which account am I in?** The toolbar badge shows the account's first letter in its color. Every
  claude.ai page also gets a thin colored strip and a name tab at the top edge. The tab doesn't
  block clicks, and you can turn it off in Settings.
- **What a switch does:** First, every open claude.ai tab moves to a "Switching…" page. Next, the
  extension swaps the claude.ai sign-in cookies and clears what claude.ai keeps in page storage.
  Then the tabs reopen at claude.ai/new. Nothing from one account is left on screen or in page
  storage for the other, and no message typed under one account can be sent from the other.

## Good to know

- **Don't use claude.ai's own *Log out*.** It ends the saved session, so you'd have to sign in and
  save that account again. To stop using an account in the switcher, open its edit menu (✎) and click **Remove**.
- **When a saved session expires** (sessions last weeks, possibly less if the firm sets a shorter
  limit), switching to it opens the sign-in page. Sign in with the same account and the switcher
  re-attaches it automatically. If it can't tell which account it is, the menu offers **Update "Work"**.
- **New sign-ins are never saved silently.** If you sign in to an account the switcher doesn't
  know, the badge shows `?`. The extension won't switch away from that sign-in until you save it
  or choose **Continue without saving**.
- **Drafts and open conversations don't follow you.** Unsent text and the open chat are cleared when you switch. This is deliberate.
- **One account at a time per Edge profile.** All claude.ai tabs in the profile use the same
  account. To keep both open side by side, use two Edge profiles (below).
- **Only the claude.ai website changes.** The Claude desktop app, the mobile apps, and Claude Code keep their own sign-ins.

## Security and privacy

- **Permissions:** Cookie and site access for `claude.ai` only, extension storage, and
  `browsingData` (used only to clear claude.ai's page storage). The extension makes no network
  requests of its own and has no analytics. The code is short and readable. `background.js` does all the work.
- **Where saved sign-ins live:** In this Edge profile's extension storage, on this computer. They
  are never synced to other devices. They are **not encrypted**. Anyone who can read your Windows
  user files could copy them and use your Claude accounts. Edge's own cookie store is encrypted with
  your Windows login, so this is weaker protection than signing in normally. Use the extension only
  on a computer you trust. **Remove** deletes an account's saved sign-in, and uninstalling the extension deletes all of them.
- **What a saved sign-in is:** It's equivalent to being signed in. Never share the extension's data
  folder or a copy of your Edge profile.

## Alternative that needs no extension: two Edge profiles

Edge profiles keep the two accounts completely separate, and both can stay open at once:

1. Click your profile picture in Edge, then **Other profiles**, then **Add profile**. Name the new profiles "Work" and "Personal".
2. In each profile, sign in to claude.ai with that profile's account.
3. Optional: in each profile, open claude.ai, then **⋯**, then **Apps** (under **More tools** in some versions), then **Install this site as
   an app**. This gives you separate "Claude" windows and taskbar icons for work and personal.

## How it was tested

The extension was tested in Chromium 153, the engine Edge is built on, against a local stand-in
for claude.ai. The stand-in uses the same kinds of cookies as the real site. The tests covered
saving, adding, switching, the keyboard shortcut, re-sign-in, expired sessions, unsaved-sign-in
protection, clearing page storage, and the on-page label. It has not been run against the live
claude.ai. If Anthropic changes how claude.ai signs you in, the extension may stop working.
